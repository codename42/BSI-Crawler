# BSI-Crawler 2.0 – grafische Oberfläche

Version 2.0 baut auf der **unveränderten CLI-Engine von Version 1.5.1** auf und ergänzt `gui.py` (Tkinter). Die vorhandenen Befehle in `main.py` bleiben nutzbar.

## Installation (Ubuntu/Debian)

```bash
sudo apt install python3-tk
python3 gui.py
# alternativ: ./start_gui.sh
```

## Sichere Übernahme aus Version 1.5.1

1. Dieses ZIP **in einen neuen Ordner** entpacken, nicht über die alte Version.
2. GUI starten und unter **Datenbank übernehmen (Kopie)** die alte `catalog_v14.sqlite3` auswählen. Die Kopie wird standardmäßig nach `data/catalog_v20.sqlite3` geschrieben. Die alte Datei wird nicht verändert.
3. Für bereits vorhandene PDFs den bisherigen `downloads`-Ordner **kopieren** und im Download-Tab als Zielordner auswählen. Alternativ den alten Download-Ordner direkt auswählen; dadurch werden jedoch neue Downloads im alten Ordner gespeichert. Eine Kopie ist sicherer.
4. Mit **Dokumente anzeigen** und **Download-Zeitpunkte** den übernommenen Katalog prüfen.

## GUI

- **Crawl:** Start-URL, Seiten- und Dateilimit, Verzögerung, Sitemaps.
- **Katalog / Historie:** Dateien nach Kategorie anzeigen, URL-Versionen und Download-Zeitpunkte anzeigen.
- **Downloads:** Einzelne IDs oder Kategorie auswählen; `Dry Run` ist standardmäßig aktiviert. Erst nach Deaktivierung werden Dateien tatsächlich heruntergeladen. `--force` lädt erneut.
- **CSV-Export:** Katalog als CSV exportieren (mit Excel importierbar).
- **Protokoll:** Live-Ausgabe des CLI-Programms und Abbruch laufender Vorgänge.

Die GUI verwendet die bewährten CLI-Befehle über `subprocess` ohne Shell. Netzwerkregeln, `robots.txt`, Größenbegrenzung, Versionierung und SQLite-Migration bleiben Aufgabe der bestehenden Engine.

## Tests

```bash
python3 -m unittest discover -s tests -v
```

Die GUI benötigt eine grafische Linux-Sitzung und das Paket `python3-tk`. Die Tests der Befehlsbildung benötigen kein geöffnetes Fenster.

## Einschränkungen

- Keine Excel-XLSX-Ausgabe; CSV kann in Excel geöffnet werden.
- Noch kein Scheduler oder Hintergrunddienst.
- Kein automatisches Kopieren vorhandener Downloads beim Datenbankimport; das ist ein separater Schritt.
- `--force` prüft den Server erneut; normales Überspringen ist nur eine lokale Prüfung.
