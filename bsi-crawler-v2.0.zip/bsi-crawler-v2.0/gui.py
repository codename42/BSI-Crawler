#!/usr/bin/env python3
"""Tkinter frontend for the unchanged v1.5.1 command-line engine."""
import queue
import sqlite3
import subprocess
import sys
import threading
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

ROOT = Path(__file__).resolve().parent
CATEGORIES = ('Alle', 'document', 'table', 'presentation', 'archive', 'image', 'media', 'signature_or_certificate', 'other')


def build_command(action, values):
    """Build a safe argv list (never shell=True)."""
    db = str(Path(values['db']).expanduser().resolve())
    command = [sys.executable, '-u', str(ROOT / 'main.py'), action, '--db', db]
    if action == 'crawl':
        command += ['--seed', values['seed'], '--max-pages', str(int(values['max_pages'])),
                    '--max-files', str(int(values['max_files'])), '--delay', str(float(values['delay']))]
        if values.get('no_sitemaps'): command.append('--no-sitemaps')
    elif action == 'download':
        command += ['--output-dir', str(Path(values['output_dir']).expanduser().resolve()),
                    '--limit', str(int(values['limit'])), '--delay', str(float(values['delay']))]
        ids = values.get('ids', '').strip()
        if ids:
            for token in ids.replace(';', ',').split(','):
                if token.strip(): command += ['--id', str(int(token.strip()))]
        elif values.get('category') and values['category'] != 'Alle':
            command += ['--category', values['category']]
        else: command.append('--all')
        if values.get('dry_run'): command.append('--dry-run')
        if values.get('force'): command.append('--force')
    elif action == 'export':
        command += ['--output', str(Path(values['csv']).expanduser().resolve())]
    else:
        command += ['--limit', str(int(values['limit']))]
        if action == 'list' and values.get('category') not in (None, 'Alle'):
            command += ['--category', values['category']]
    return command


class Application(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title('BSI-Crawler 2.0 – Dokumentenkatalog')
        self.geometry('1020x740')
        self.minsize(800, 560)
        self.events = queue.Queue()
        self.process = None
        self.running = False
        self.db = tk.StringVar(value=str(ROOT / 'data' / 'catalog_v20.sqlite3'))
        self.seed = tk.StringVar(value='https://www.bsi.bund.de/')
        self.max_pages = tk.StringVar(value='100')
        self.max_files = tk.StringVar(value='200')
        self.delay = tk.StringVar(value='3')
        self.no_sitemaps = tk.BooleanVar(value=True)
        self.category = tk.StringVar(value='document')
        self.limit = tk.StringVar(value='20')
        self.ids = tk.StringVar()
        self.output_dir = tk.StringVar(value=str(ROOT / 'downloads'))
        self.csv = tk.StringVar(value=str(ROOT / 'data' / 'bsi_documents.csv'))
        self.dry_run = tk.BooleanVar(value=True)
        self.force = tk.BooleanVar(value=False)
        self.status = tk.StringVar(value='Bereit. Bestehende Datenbank über „Datenbank übernehmen“ kopieren.')
        self._build()
        self.after(100, self._drain)
        self.protocol('WM_DELETE_WINDOW', self._close)

    def _entry(self, parent, label, var, row, width=48, browse=None):
        ttk.Label(parent, text=label).grid(row=row, column=0, sticky='w', padx=8, pady=5)
        ttk.Entry(parent, textvariable=var, width=width).grid(row=row, column=1, sticky='ew', padx=8, pady=5)
        if browse:
            ttk.Button(parent, text='Durchsuchen', command=browse).grid(row=row, column=2, padx=8)

    def _build(self):
        top = ttk.LabelFrame(self, text='Datenbank (gemeinsam für alle Funktionen)')
        top.pack(fill='x', padx=12, pady=8)
        top.columnconfigure(1, weight=1)
        self._entry(top, 'SQLite-Datei', self.db, 0, browse=self._choose_db)
        ttk.Button(top, text='Datenbank übernehmen (Kopie)', command=self._copy_db).grid(row=1, column=1, sticky='w', padx=8, pady=5)
        notebook = ttk.Notebook(self)
        notebook.pack(fill='x', padx=12, pady=5)
        crawl = ttk.Frame(notebook); notebook.add(crawl, text='Crawl')
        crawl.columnconfigure(1, weight=1)
        self._entry(crawl, 'Start-URL', self.seed, 0)
        self._entry(crawl, 'Max. Seiten', self.max_pages, 1)
        self._entry(crawl, 'Max. Dateien', self.max_files, 2)
        self._entry(crawl, 'Verzögerung (Sek.)', self.delay, 3)
        ttk.Checkbutton(crawl, text='Keine Sitemaps', variable=self.no_sitemaps).grid(row=4, column=1, sticky='w', padx=8)
        ttk.Button(crawl, text='Crawl starten', command=lambda: self._run('crawl')).grid(row=5, column=1, sticky='w', padx=8, pady=8)
        catalog = ttk.Frame(notebook); notebook.add(catalog, text='Katalog / Historie')
        catalog.columnconfigure(1, weight=1)
        ttk.Label(catalog, text='Kategorie').grid(row=0, column=0, sticky='w', padx=8, pady=5)
        ttk.Combobox(catalog, textvariable=self.category, values=CATEGORIES, state='readonly').grid(row=0, column=1, sticky='w', padx=8)
        self._entry(catalog, 'Max. Einträge', self.limit, 1)
        actions = ttk.Frame(catalog); actions.grid(row=2, column=1, sticky='w', padx=8, pady=8)
        for name, action in [('Dokumente anzeigen', 'list'), ('Versionshistorie', 'history'), ('Download-Zeitpunkte', 'downloads-history')]:
            ttk.Button(actions, text=name, command=lambda a=action: self._run(a)).pack(side='left', padx=3)
        download = ttk.Frame(notebook); notebook.add(download, text='Downloads')
        download.columnconfigure(1, weight=1)
        self._entry(download, 'IDs (optional, z.B. 1,2,5)', self.ids, 0)
        self._entry(download, 'Zielordner', self.output_dir, 1, browse=self._choose_output)
        ttk.Checkbutton(download, text='Nur planen (Dry Run)', variable=self.dry_run).grid(row=2, column=1, sticky='w', padx=8)
        ttk.Checkbutton(download, text='Erneut herunterladen (--force)', variable=self.force).grid(row=3, column=1, sticky='w', padx=8)
        ttk.Label(download, text='Ohne IDs: Kategorie und Limit aus „Katalog / Historie“').grid(row=4, column=1, sticky='w', padx=8)
        ttk.Button(download, text='Download starten', command=lambda: self._run('download')).grid(row=5, column=1, sticky='w', padx=8, pady=8)
        export = ttk.Frame(notebook); notebook.add(export, text='CSV-Export')
        export.columnconfigure(1, weight=1)
        self._entry(export, 'CSV-Datei', self.csv, 0, browse=self._choose_csv)
        ttk.Button(export, text='CSV exportieren', command=lambda: self._run('export')).grid(row=1, column=1, sticky='w', padx=8, pady=8)
        logframe = ttk.LabelFrame(self, text='Protokoll')
        logframe.pack(fill='both', expand=True, padx=12, pady=8)
        self.log = tk.Text(logframe, wrap='word', height=16, state='disabled')
        scroll = ttk.Scrollbar(logframe, orient='vertical', command=self.log.yview)
        self.log.configure(yscrollcommand=scroll.set)
        self.log.pack(side='left', fill='both', expand=True)
        scroll.pack(side='right', fill='y')
        bottom = ttk.Frame(self); bottom.pack(fill='x', padx=12, pady=(0, 12))
        ttk.Label(bottom, textvariable=self.status).pack(side='left', fill='x', expand=True)
        self.cancel = ttk.Button(bottom, text='Lauf abbrechen', command=self._cancel, state='disabled')
        self.cancel.pack(side='right')
        ttk.Button(bottom, text='Protokoll löschen', command=self._clear).pack(side='right', padx=8)

    def _choose_db(self):
        path = filedialog.askopenfilename(filetypes=[('SQLite', '*.sqlite3'), ('Alle Dateien', '*')])
        if path: self.db.set(path)

    def _choose_output(self):
        path = filedialog.askdirectory()
        if path: self.output_dir.set(path)

    def _choose_csv(self):
        path = filedialog.asksaveasfilename(defaultextension='.csv', filetypes=[('CSV', '*.csv')])
        if path: self.csv.set(path)

    def _copy_db(self):
        if self.running: return
        source = filedialog.askopenfilename(title='Bestehende SQLite-Datenbank auswählen', filetypes=[('SQLite', '*.sqlite3'), ('Alle Dateien', '*')])
        if not source: return
        destination = Path(self.db.get()).expanduser().resolve()
        if Path(source).resolve() == destination:
            messagebox.showerror('Ungültiges Ziel', 'Quelle und Ziel müssen verschieden sein.')
            return
        if destination.exists() and not messagebox.askyesno('Datenbank überschreiben?', f'{destination} existiert bereits. Kopie überschreiben?'):
            return
        try:
            destination.parent.mkdir(parents=True, exist_ok=True)
            with sqlite3.connect(f'file:{Path(source).resolve()}?mode=ro', uri=True) as src, sqlite3.connect(destination) as dst:
                src.backup(dst)
            self._append(f'[DB] Sicherungskopie erstellt: {destination}\n')
        except Exception as exc:
            messagebox.showerror('Datenbankübernahme fehlgeschlagen', str(exc))

    def _values(self):
        return dict(db=self.db.get(), seed=self.seed.get(), max_pages=self.max_pages.get(),
                    max_files=self.max_files.get(), delay=self.delay.get(), no_sitemaps=self.no_sitemaps.get(),
                    category=self.category.get(), limit=self.limit.get(), ids=self.ids.get(),
                    output_dir=self.output_dir.get(), csv=self.csv.get(), dry_run=self.dry_run.get(), force=self.force.get())

    def _run(self, action):
        if self.running: return
        try:
            values = self._values()
            command = build_command(action, values)
            if action != 'crawl' and not Path(values['db']).expanduser().is_file():
                raise ValueError('Datenbank fehlt. Zuerst eine bestehende Datenbank übernehmen oder einen Crawl starten.')
            if action == 'crawl':
                Path(values['db']).expanduser().resolve().parent.mkdir(parents=True, exist_ok=True)
            if action == 'export': Path(values['csv']).expanduser().resolve().parent.mkdir(parents=True, exist_ok=True)
        except (ValueError, OSError) as exc:
            messagebox.showerror('Ungültige Eingabe', str(exc)); return
        self.running = True
        self.cancel.configure(state='normal')
        self.status.set(f'{action} läuft …')
        self._append('\n$ ' + ' '.join(command) + '\n')
        threading.Thread(target=self._worker, args=(command,), daemon=True).start()

    def _worker(self, command):
        try:
            self.process = subprocess.Popen(command, cwd=ROOT, stdout=subprocess.PIPE,
                                            stderr=subprocess.STDOUT, text=True, encoding='utf-8', errors='replace', bufsize=1)
            for line in self.process.stdout: self.events.put(('line', line))
            code = self.process.wait()
            self.events.put(('done', code))
        except Exception as exc: self.events.put(('error', str(exc)))

    def _drain(self):
        try:
            while True:
                kind, value = self.events.get_nowait()
                if kind == 'line': self._append(value)
                elif kind == 'done':
                    self._finish(f'Fertig (Exit-Code {value})' if value else 'Fertig (erfolgreich)')
                else:
                    self._append('[FEHLER] ' + value + '\n'); self._finish('Fehler')
        except queue.Empty: pass
        self.after(100, self._drain)

    def _append(self, text):
        self.log.configure(state='normal'); self.log.insert('end', text)
        self.log.see('end'); self.log.configure(state='disabled')

    def _clear(self):
        self.log.configure(state='normal'); self.log.delete('1.0', 'end'); self.log.configure(state='disabled')

    def _finish(self, status):
        self.running = False; self.process = None
        self.cancel.configure(state='disabled'); self.status.set(status)

    def _cancel(self):
        if self.process and self.process.poll() is None:
            self.process.terminate()
            self.status.set('Abbruch angefordert …')

    def _close(self):
        if self.running:
            messagebox.showwarning('Vorgang läuft', 'Bitte zuerst den laufenden Vorgang abbrechen und auf dessen Ende warten.')
            return
        self.destroy()


if __name__ == '__main__':
    Application().mainloop()
