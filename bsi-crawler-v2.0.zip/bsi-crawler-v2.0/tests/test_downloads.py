import sqlite3
import tempfile
import threading
import unittest
from pathlib import Path
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from bsi_crawler.core import Crawler
from bsi_crawler.downloads import DownloadManager, file_sha256

DATA = b'%PDF-1.4\nlocal-test\n'
class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/robots.txt':
            body = b'User-agent: *\nDisallow: /private\nAllow: /\n'
        elif self.path == '/a.pdf': body = DATA
        elif self.path == '/redirect':
            self.send_response(302); self.send_header('Location','/a.pdf'); self.end_headers(); return
        else: self.send_response(404); self.end_headers(); return
        self.send_response(200)
        self.send_header('Content-Type', 'application/pdf' if self.path.endswith('.pdf') else 'text/plain')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers(); self.wfile.write(body)
    def log_message(self, *args): pass

class DownloadTests(unittest.TestCase):
    def test_download_skip_force_size_and_robots(self):
        server = ThreadingHTTPServer(('127.0.0.1',0),Handler)
        thread = threading.Thread(target=server.serve_forever,daemon=True); thread.start()
        try:
            with tempfile.TemporaryDirectory() as tmp:
                root = f'http://127.0.0.1:{server.server_port}'
                db = Path(tmp)/'db.sqlite'
                crawler = Crawler(db, root, ['127.0.0.1'], delay=0, use_sitemaps=False)
                for name in ('a.pdf','redirect','private/file.pdf'):
                    crawler.record_file(root+'/'+name,root)
                mgr = DownloadManager(db, Path(tmp)/'downloads', delay=0)
                rows = mgr.select(all_files=True,limit=10)
                self.assertEqual(len(rows),3)
                self.assertEqual(mgr.download(rows,dry_run=True)['downloaded'],0)
                result = mgr.download(rows)
                self.assertEqual(result,{'downloaded':2,'skipped':0,'failed':1})
                with sqlite3.connect(db) as con:
                    self.assertIn('robots.txt', con.execute("SELECT error FROM downloads WHERE document_url=?",(root+'/private/file.pdf',)).fetchone()[0])
                with sqlite3.connect(db) as con:
                    row = con.execute("SELECT local_path,sha256 FROM downloads WHERE document_url=?",(root+'/a.pdf',)).fetchone()
                self.assertEqual(file_sha256(row[0]),row[1])
                self.assertEqual(mgr.download(rows[:2])['skipped'],2)
                small = DownloadManager(db,Path(tmp)/'downloads',delay=0,max_bytes=4)
                self.assertEqual(small.download(rows[:1],force=True)['failed'],1)
                self.assertFalse(list(Path(tmp).rglob('*.part')))
        finally:
            server.shutdown();server.server_close();thread.join()
