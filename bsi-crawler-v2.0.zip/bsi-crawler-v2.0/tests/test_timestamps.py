import sqlite3
import tempfile
import unittest
from pathlib import Path
from bsi_crawler.downloads import DownloadManager
from bsi_crawler.core import Crawler

class TimestampTests(unittest.TestCase):
    def test_legacy_download_migration(self):
        with tempfile.TemporaryDirectory() as tmp:
            db = Path(tmp)/'test.sqlite3'
            with sqlite3.connect(db) as con:
                con.execute('CREATE TABLE downloads (document_url TEXT PRIMARY KEY, local_path TEXT, sha256 TEXT, bytes INTEGER, status TEXT, downloaded_at TEXT, error TEXT)')
                con.execute("INSERT INTO downloads(document_url,status,downloaded_at) VALUES ('https://example.com/a.pdf','downloaded','2026-10-15 15:24:00')")
            DownloadManager(db,Path(tmp)/'downloads',0,5,1024)
            with sqlite3.connect(db) as con:
                first,last = con.execute('SELECT first_downloaded_at,last_checked_at FROM downloads').fetchone()
            self.assertEqual(first,'2026-10-15 15:24:00')
            self.assertIsNone(last)

    def test_crawl_statistics_known_vs_new(self):
        with tempfile.TemporaryDirectory() as tmp:
            c=Crawler(Path(tmp)/'test.sqlite3','https://www.bsi.bund.de/', ['www.bsi.bund.de'],1,10,0,1,False)
            c.record_file('https://www.bsi.bund.de/SharedDocs/a.pdf?v=1','https://www.bsi.bund.de/')
            c.record_file('https://www.bsi.bund.de/SharedDocs/a.pdf?v=1','https://www.bsi.bund.de/')
            c.record_file('https://www.bsi.bund.de/SharedDocs/a.pdf?v=2','https://www.bsi.bund.de/')
            self.assertEqual((c.stats['new_files'],c.stats['known_files'],c.stats['version_changes']),(2,1,1))
