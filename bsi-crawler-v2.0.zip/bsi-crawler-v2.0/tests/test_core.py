import csv
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import tempfile
import threading
import unittest
from bsi_crawler.core import Crawler, export_csv, canonical, is_file, resolve_link

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/redirect':
            self.send_response(302); self.send_header('Location', '/'); self.end_headers(); return
        if self.path == '/external':
            self.send_response(302); self.send_header('Location', 'https://example.com/'); self.end_headers(); return
        pages = {
            '/robots.txt': ('text/plain', b'User-agent: *\nAllow: /\n'),
            '/': ('text/html', b'<html><title>Start</title><a href="/next">Next</a><a href="/files/a.pdf">PDF</a></html>'),
            '/next': ('text/html', b'<html><a href="/files/b.zip">ZIP</a><a href="/files/a.pdf">Duplicate</a></html>'),
        }
        if self.path not in pages:
            self.send_response(404); self.end_headers(); return
        content_type, body = pages[self.path]
        self.send_response(200); self.send_header('Content-Type',content_type)
        self.send_header('Content-Length',str(len(body))); self.end_headers(); self.wfile.write(body)
    def log_message(self, *args): pass

class Tests(unittest.TestCase):
    def test_canonical_and_extensions(self):
        self.assertEqual(canonical('HTTP://Example.org/a.pdf#part'), 'http://example.org/a.pdf')
        self.assertTrue(is_file('https://example.org/a.PDF?download=1'))
        self.assertFalse(is_file('https://example.org/page'))
    def test_bsi_root_paths(self):
        base = 'https://www.bsi.bund.de/DE/Home/home_node.html'
        self.assertEqual(resolve_link(base, 'DE/Themen/themen_node.html'),
                         'https://www.bsi.bund.de/DE/Themen/themen_node.html')
        self.assertEqual(resolve_link(base, 'SharedDocs/Downloads/a.pdf'),
                         'https://www.bsi.bund.de/SharedDocs/Downloads/a.pdf')
        self.assertEqual(resolve_link(base, '../andere.html'),
                         'https://www.bsi.bund.de/DE/andere.html')
    def test_catalog_metadata_and_sources(self):
        import sqlite3
        from bsi_crawler.core import logical_file_url
        with tempfile.TemporaryDirectory() as tmp:
            db = Path(tmp)/'catalog.sqlite3'
            crawler = Crawler(db, 'https://www.bsi.bund.de/', ['www.bsi.bund.de'],
                              delay=0, use_sitemaps=False)
            url = 'https://www.bsi.bund.de/SharedDocs/a.pdf?__blob=publicationFile&v=3'
            crawler.record_file(url, 'https://www.bsi.bund.de/DE/a.html')
            crawler.record_file(url, 'https://www.bsi.bund.de/DE/b.html')
            crawler.record_file(url, 'https://www.bsi.bund.de/DE/b.html')
            self.assertEqual(crawler.stats['files'], 1)
            with sqlite3.connect(db) as con:
                row = con.execute('SELECT category,version_tag,logical_url,source_count FROM documents').fetchone()
                self.assertEqual(row, ('document','3',logical_file_url(url),2))
            output = Path(tmp)/'export.csv'
            export_csv(db, output)
            with output.open(newline='') as f:
                rows = list(csv.DictReader(f))
            self.assertEqual(rows[0]['source_count'], '2')
            self.assertEqual(rows[0]['category'], 'document')

    def test_migration_existing_database(self):
        import sqlite3
        with tempfile.TemporaryDirectory() as tmp:
            db = Path(tmp)/'old.sqlite3'
            with sqlite3.connect(db) as con:
                con.execute('''CREATE TABLE documents (url TEXT PRIMARY KEY, filename TEXT NOT NULL,
                    extension TEXT, first_seen TEXT DEFAULT CURRENT_TIMESTAMP,
                    last_seen TEXT DEFAULT CURRENT_TIMESTAMP, discovered_from TEXT NOT NULL,
                    status TEXT DEFAULT 'discovered')''')
                con.execute("INSERT INTO documents(url,filename,extension,discovered_from) VALUES ('https://x/a.pdf','a.pdf','.pdf','https://x/')")
            Crawler(db, 'https://x/', ['x'], use_sitemaps=False)
            with sqlite3.connect(db) as con:
                cols = {r[1] for r in con.execute('PRAGMA table_info(documents)')}
                self.assertTrue({'category','version_tag','logical_url','source_count'} <= cols)
                self.assertEqual(con.execute('SELECT count(*) FROM documents').fetchone()[0], 1)

    def test_redirects(self):
        server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            with tempfile.TemporaryDirectory() as tmp:
                root = f'http://127.0.0.1:{server.server_port}'
                crawler = Crawler(Path(tmp)/'db.sqlite', root+'/redirect', ['127.0.0.1'],
                                  max_pages=2, max_files=10, delay=0, use_sitemaps=False)
                stats = crawler.run()
                self.assertEqual(stats['pages'], 2)
                self.assertEqual(stats['files'], 2)
                self.assertEqual(stats['errors'], 0)
                self.assertIsNone(crawler.fetch(root+'/external'))
                self.assertEqual(crawler.stats['errors'], 1)
        finally:
            server.shutdown(); server.server_close(); thread.join()

    def test_local_crawl_and_export(self):
        server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            with tempfile.TemporaryDirectory() as tmp:
                root = f'http://127.0.0.1:{server.server_port}/'
                db = Path(tmp)/'catalog.sqlite3'
                crawler = Crawler(db, root, ['127.0.0.1'], max_pages=3, max_files=10, delay=0, use_sitemaps=False)
                stats = crawler.run()
                self.assertEqual(stats['pages'], 2)
                self.assertEqual(stats['files'], 2)
                output = Path(tmp)/'result.csv'
                export_csv(db, output)
                with output.open(newline='') as f: rows = list(csv.DictReader(f))
                self.assertEqual(len(rows), 2)
                self.assertEqual({r['extension'] for r in rows}, {'.pdf','.zip'})
        finally:
            server.shutdown(); server.server_close(); thread.join()

if __name__ == '__main__': unittest.main()
