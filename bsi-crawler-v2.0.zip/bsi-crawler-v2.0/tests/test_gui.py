import unittest
from pathlib import Path
from gui import build_command

class GuiCommandTests(unittest.TestCase):
    def setUp(self):
        self.values = dict(db='data/test.sqlite3', seed='https://www.bsi.bund.de/', max_pages='100', max_files='200', delay='3', no_sitemaps=True, category='document', limit='5', ids='', output_dir='downloads', csv='data/output.csv', dry_run=True, force=False)

    def test_crawl_command(self):
        args = build_command('crawl', self.values)
        self.assertIn('--no-sitemaps', args)
        self.assertEqual(args[args.index('--max-pages') + 1], '100')

    def test_download_command(self):
        self.values['ids'] = '1, 3;5'
        args = build_command('download', self.values)
        self.assertEqual(args.count('--id'), 3)
        self.assertIn('--dry-run', args)
        self.assertNotIn('--all', args)

    def test_list_command(self):
        args = build_command('list', self.values)
        self.assertEqual(args[args.index('--category') + 1], 'document')

if __name__ == '__main__': unittest.main()
