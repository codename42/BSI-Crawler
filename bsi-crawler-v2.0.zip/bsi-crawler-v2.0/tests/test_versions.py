import sqlite3
import tempfile
import unittest
from pathlib import Path
from bsi_crawler.core import Crawler
from bsi_crawler.downloads import DownloadManager, file_sha256

class VersionTests(unittest.TestCase):
    def test_url_version_events_and_archive(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            db = root/'catalog.sqlite3'
            crawler = Crawler(db, 'https://www.bsi.bund.de/', ['www.bsi.bund.de'], delay=0, use_sitemaps=False)
            u1 = 'https://www.bsi.bund.de/SharedDocs/a.pdf?__blob=publicationFile&v=1'
            u2 = 'https://www.bsi.bund.de/SharedDocs/a.pdf?__blob=publicationFile&v=2'
            crawler.record_file(u1, crawler.seed)
            crawler.record_file(u2, crawler.seed)
            crawler.record_file(u2, crawler.seed)
            with sqlite3.connect(db) as con:
                rows = con.execute('SELECT previous_url,document_url FROM version_events').fetchall()
            self.assertEqual(rows, [(u1,u2)])
            manager = DownloadManager(db, root/'downloads', delay=0)
            content = [b'first', b'second']
            manager._fetch_file = lambda url, temp: (temp.write_bytes(content.pop(0)), file_sha256(temp))
            row = [(1,u1,'a.pdf','document')]
            self.assertEqual(manager.download(row)['downloaded'], 1)
            self.assertEqual(manager.download(row,force=True)['downloaded'], 1)
            with sqlite3.connect(db) as con:
                versions = con.execute('SELECT local_path,sha256 FROM download_versions ORDER BY id').fetchall()
            self.assertEqual(len(versions), 2)
            self.assertEqual({Path(path).read_bytes() for path,_ in versions}, {b'first',b'second'})

if __name__ == '__main__': unittest.main()
