"""Bounded downloads of catalogued files; no third-party dependencies."""
from __future__ import annotations
import hashlib
import shutil
from pathlib import Path
import re
import sqlite3
import time
from urllib.error import HTTPError, URLError
from urllib.parse import urljoin, urlparse
from urllib.request import Request, build_opener
from urllib.robotparser import RobotFileParser
from .core import AGENT, NoRedirect, canonical

CHUNK = 128 * 1024

def file_sha256(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(CHUNK), b''):
            digest.update(chunk)
    return digest.hexdigest()

class DownloadManager:
    def __init__(self, db: Path, directory: Path, delay: float = 3.0,
                 timeout: float = 30.0, max_bytes: int = 100 * 1024 * 1024):
        self.db, self.directory = Path(db), Path(directory)
        self.delay, self.timeout, self.max_bytes = delay, timeout, max_bytes
        self.directory.mkdir(parents=True, exist_ok=True)
        self.opener = build_opener(NoRedirect())
        self.last_request = {}
        self.robots = {}
        with sqlite3.connect(self.db) as con:
            con.execute('''CREATE TABLE IF NOT EXISTS downloads (
                document_url TEXT PRIMARY KEY, local_path TEXT, sha256 TEXT,
                bytes INTEGER, status TEXT NOT NULL DEFAULT 'pending',
                downloaded_at TEXT, error TEXT)''')
            con.execute('''CREATE TABLE IF NOT EXISTS download_versions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                document_url TEXT NOT NULL, local_path TEXT NOT NULL,
                sha256 TEXT NOT NULL, bytes INTEGER NOT NULL,
                downloaded_at TEXT DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(document_url,sha256))''')
            con.execute('''CREATE TABLE IF NOT EXISTS download_attempts (
                id INTEGER PRIMARY KEY AUTOINCREMENT, document_url TEXT NOT NULL,
                attempted_at TEXT DEFAULT CURRENT_TIMESTAMP, status TEXT NOT NULL,
                message TEXT)''')
            # Migration is additive: existing v1.4/v1.5 records are preserved.
            cols = {row[1] for row in con.execute('PRAGMA table_info(downloads)')}
            for column in ('first_downloaded_at', 'last_checked_at'):
                if column not in cols:
                    con.execute(f'ALTER TABLE downloads ADD COLUMN {column} TEXT')
            con.execute('''UPDATE downloads SET first_downloaded_at=downloaded_at
                WHERE first_downloaded_at IS NULL AND downloaded_at IS NOT NULL''')
            # A legacy downloaded_at value is an existing database timestamp,
            # not an inferred timestamp from the file system.


    def _request(self, url, accept='*/*'):
        origin = f'{urlparse(url).scheme}://{urlparse(url).netloc}'
        wait = self.delay - (time.monotonic() - self.last_request.get(origin, -1e12))
        if wait > 0: time.sleep(wait)
        self.last_request[origin] = time.monotonic()
        return self.opener.open(Request(url, headers={'User-Agent': AGENT, 'Accept': accept}), timeout=self.timeout)

    def _allowed(self, url, initial_host):
        p = urlparse(url)
        return p.scheme in ('http', 'https') and p.hostname == initial_host

    def _robots_allowed(self, url):
        p = urlparse(url)
        origin = f'{p.scheme}://{p.netloc}'
        if origin not in self.robots:
            rp = RobotFileParser()
            try:
                with self._request(origin + '/robots.txt', 'text/plain') as response:
                    if response.status != 200: return False
                    data = response.read(1024 * 1024 + 1)
                    if len(data) > 1024 * 1024: return False
                rp.parse(data.decode('utf-8', errors='replace').splitlines())
                self.robots[origin] = rp
            except HTTPError as exc:
                if exc.code in (404, 410):
                    rp.parse([])
                    self.robots[origin] = rp
                else: return False
            except (OSError, ValueError): return False
        return self.robots[origin].can_fetch(AGENT, url)

    def _fetch_file(self, url, temp_path):
        original_host = urlparse(url).hostname
        seen = set()
        for _ in range(6):
            if url in seen or not self._allowed(url, original_host):
                raise ValueError('Unzulässige oder zyklische Weiterleitung')
            seen.add(url)
            if not self._robots_allowed(url):
                raise ValueError('Durch robots.txt ausgeschlossen oder nicht überprüfbar')
            try:
                response = self._request(url)
            except HTTPError as exc:
                if exc.code in (301,302,303,307,308):
                    location = exc.headers.get('Location')
                    if not location: raise ValueError('Weiterleitung ohne Location')
                    url = canonical(urljoin(url, location))
                    continue
                raise
            with response:
                length = response.headers.get('Content-Length')
                if length and int(length) > self.max_bytes:
                    raise ValueError('Datei überschreitet Größenlimit')
                digest = hashlib.sha256()
                total = 0
                with temp_path.open('wb') as f:
                    while True:
                        chunk = response.read(min(CHUNK, self.max_bytes - total + 1))
                        if not chunk: break
                        total += len(chunk)
                        if total > self.max_bytes: raise ValueError('Datei überschreitet Größenlimit')
                        digest.update(chunk)
                        f.write(chunk)
                if response.headers.get('Content-Type','').lower().startswith('text/html'):
                    raise ValueError('Server lieferte HTML statt Datei')
                return total, digest.hexdigest()
        raise ValueError('Zu viele Weiterleitungen')

    def select(self, ids=None, category=None, all_files=False, limit=20):
        with sqlite3.connect(self.db) as con:
            if ids:
                placeholders = ','.join('?' for _ in ids)
                rows = con.execute(f'SELECT rowid,url,filename,category FROM documents WHERE rowid IN ({placeholders}) ORDER BY rowid', ids).fetchall()
                if len(rows) != len(set(ids)):
                    raise ValueError('Mindestens eine Katalog-ID existiert nicht')
            else:
                if not all_files and not category:
                    raise ValueError('Bitte --id, --category oder --all angeben')
                sql = 'SELECT rowid,url,filename,category FROM documents WHERE 1=1'
                params = []
                if category:
                    sql += ' AND category=?'; params.append(category)
                sql += ' ORDER BY rowid LIMIT ?'; params.append(limit)
                rows = con.execute(sql, params).fetchall()
        return rows

    def download(self, rows, force=False, dry_run=False):
        stats = {'downloaded': 0, 'skipped': 0, 'failed': 0}
        for doc_id, url, filename, category in rows:
            safe = re.sub(r'[^\w.\-]+', '_', Path(filename).name, flags=re.UNICODE).strip('._') or 'download'
            target = self.directory / category / f'{doc_id}_{safe}'
            with sqlite3.connect(self.db) as con:
                previous = con.execute('SELECT local_path,sha256,status FROM downloads WHERE document_url=?', (url,)).fetchone()
            if not force and previous and previous[2] == 'downloaded' and previous[0]:
                path = Path(previous[0])
                if path.is_file() and file_sha256(path) == previous[1]:
                    with sqlite3.connect(self.db) as con:
                        con.execute('UPDATE downloads SET last_checked_at=CURRENT_TIMESTAMP WHERE document_url=?', (url,))
                        con.execute("INSERT INTO download_attempts(document_url,status,message) VALUES (?,'skipped','Local SHA-256 verified; no HTTP request')", (url,))
                    print(f'[SKIP] {doc_id}: {path}')
                    stats['skipped'] += 1
                    continue
            if dry_run:
                print(f'[PLAN] {doc_id}: {url} -> {target}')
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            temporary = target.with_name(target.name + '.part')
            try:
                size, sha = self._fetch_file(url, temporary)
                # Archive the previous content before replacing it. Different
                # contents are never overwritten in the immutable history.
                history_dir = self.directory / 'history' / str(doc_id)
                with sqlite3.connect(self.db) as con:
                    prior_versions = con.execute('SELECT sha256,local_path FROM download_versions WHERE document_url=?', (url,)).fetchall()
                    previous_download = con.execute('SELECT local_path,sha256,bytes FROM downloads WHERE document_url=? AND status="downloaded"', (url,)).fetchone()
                if previous_download and previous_download[0]:
                    old_path = Path(previous_download[0])
                    if old_path.is_file():
                        old_hash = file_sha256(old_path)
                        if old_hash == previous_download[1] and old_hash != sha:
                            history_dir.mkdir(parents=True, exist_ok=True)
                            archive = history_dir / f'{old_hash}_{safe}'
                            if not archive.exists(): shutil.copy2(old_path, archive)
                            with sqlite3.connect(self.db) as con:
                                con.execute('''INSERT OR IGNORE INTO download_versions
                                    (document_url,local_path,sha256,bytes)
                                    VALUES (?,?,?,?)''', (url,str(archive.resolve()),old_hash,old_path.stat().st_size))
                                con.execute('''UPDATE download_versions SET local_path=? WHERE document_url=? AND sha256=?''', (str(archive.resolve()),url,old_hash))
                # A changed file is archived by hash; the catalog path remains stable.
                if previous_download and previous_download[1] != sha:
                    history_dir.mkdir(parents=True, exist_ok=True)
                    archive = history_dir / f'{sha}_{safe}'
                    if not archive.exists(): shutil.copy2(temporary, archive)
                temporary.replace(target)
                with sqlite3.connect(self.db) as con:
                    con.execute('''INSERT INTO downloads(document_url,local_path,sha256,bytes,status,downloaded_at,error)
                        VALUES (?,?,?,?, 'downloaded',CURRENT_TIMESTAMP,NULL)
                        ON CONFLICT(document_url) DO UPDATE SET local_path=excluded.local_path,
                        sha256=excluded.sha256,bytes=excluded.bytes,status='downloaded',
                        downloaded_at=CURRENT_TIMESTAMP,error=NULL''', (url,str(target.resolve()),sha,size))
                    con.execute('''UPDATE downloads SET
                        first_downloaded_at=COALESCE(first_downloaded_at, downloaded_at),
                        last_checked_at=CURRENT_TIMESTAMP WHERE document_url=?''', (url,))
                    con.execute('''INSERT OR IGNORE INTO download_versions
                        (document_url,local_path,sha256,bytes) VALUES (?,?,?,?)''',
                        (url,str((history_dir / f'{sha}_{safe}').resolve()) if previous_download and previous_download[1] != sha else str(target.resolve()),sha,size))
                    con.execute("INSERT INTO download_attempts(document_url,status,message) VALUES (?,'downloaded',?)", (url,f'{size} bytes; sha256={sha}'))
                print(f'[OK] {doc_id}: {target} ({size} Bytes)')
                stats['downloaded'] += 1
            except (OSError, ValueError, HTTPError, URLError) as exc:
                temporary.unlink(missing_ok=True)
                with sqlite3.connect(self.db) as con:
                    con.execute('''INSERT INTO downloads(document_url,status,error) VALUES (?,'failed',?)
                        ON CONFLICT(document_url) DO UPDATE SET status='failed',error=excluded.error''', (url,str(exc)))
                    con.execute('UPDATE downloads SET last_checked_at=CURRENT_TIMESTAMP WHERE document_url=?', (url,))
                    con.execute("INSERT INTO download_attempts(document_url,status,message) VALUES (?,'failed',?)", (url,str(exc)))
                print(f'[FAIL] {doc_id}: {exc}')
                stats['failed'] += 1
        return stats
