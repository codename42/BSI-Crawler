"""Bounded, polite public-site crawler using only the Python standard library."""
from __future__ import annotations
import csv
import hashlib
from html.parser import HTMLParser
import json
from pathlib import Path
import re
import sqlite3
import time
from urllib.error import HTTPError, URLError
from urllib.parse import urljoin, urldefrag, urlparse, urlunparse, unquote, parse_qs
from urllib.request import Request, build_opener, HTTPRedirectHandler
from urllib.robotparser import RobotFileParser
from xml.etree import ElementTree

AGENT = 'BSIDocumentCatalogPrototype/0.1 (+local research; respectful crawling)'
EXTENSIONS = {'.pdf','.zip','.doc','.docx','.xls','.xlsx','.ppt','.pptx','.odt','.ods','.odp','.rtf','.txt','.csv','.xml','.json','.epub','.jpg','.jpeg','.png','.svg','.gif','.webp','.mp3','.mp4','.7z','.tar','.gz','.asc','.sig','.p7s','.pem','.cer','.crt','.der','.exe','.msi'}
MAX_RESPONSE = 5 * 1024 * 1024  # Discovery pages, never binary downloads

class LinkParser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.links = []
        self.title = ''
        self.base_href = None
        self._in_title = False
    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == 'a' and attrs.get('href'):
            self.links.append((attrs['href'], attrs.get('download', '')))
        if tag == 'base' and attrs.get('href') and self.base_href is None:
            self.base_href = attrs['href']
        if tag == 'title': self._in_title = True
    def handle_endtag(self, tag):
        if tag == 'title': self._in_title = False
    def handle_data(self, data):
        if self._in_title: self.title += data

class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None

class Crawler:
    def __init__(self, db: Path, seed: str, allowed_hosts: list[str], max_pages: int = 15,
                 max_files: int = 100, delay: float = 2.0, timeout: float = 15.0,
                 use_sitemaps: bool = True):
        self.db = Path(db)
        self.seed = canonical(seed)
        self.allowed_hosts = [h.lower().strip('.') for h in allowed_hosts]
        self.max_pages = max_pages
        self.max_files = max_files
        self.delay = delay
        self.timeout = timeout
        self.use_sitemaps = use_sitemaps
        self.opener = build_opener(NoRedirect())
        self.robots = {}
        self.redirects = {}
        self.resolved = {}
        self.seen_final = set()
        self.last_request = {}
        self.stats = {'pages': 0, 'files': 0, 'errors': 0, 'skipped_robots': 0, 'known_files': 0, 'new_files': 0, 'version_changes': 0}
        self.db.parent.mkdir(parents=True, exist_ok=True)
        with self.connect() as con:
            con.executescript('''
            CREATE TABLE IF NOT EXISTS documents (
              url TEXT PRIMARY KEY, filename TEXT NOT NULL, extension TEXT,
              first_seen TEXT DEFAULT CURRENT_TIMESTAMP,
              last_seen TEXT DEFAULT CURRENT_TIMESTAMP,
              discovered_from TEXT NOT NULL, status TEXT DEFAULT 'discovered');
            CREATE TABLE IF NOT EXISTS document_sources (
              document_url TEXT NOT NULL, page_url TEXT NOT NULL,
              first_seen TEXT DEFAULT CURRENT_TIMESTAMP,
              last_seen TEXT DEFAULT CURRENT_TIMESTAMP,
              PRIMARY KEY(document_url,page_url));
            CREATE TABLE IF NOT EXISTS pages (
              url TEXT PRIMARY KEY, title TEXT, scanned_at TEXT DEFAULT CURRENT_TIMESTAMP);
            CREATE TABLE IF NOT EXISTS crawl_runs (
              id INTEGER PRIMARY KEY AUTOINCREMENT, started_at TEXT DEFAULT CURRENT_TIMESTAMP,
              finished_at TEXT, pages INTEGER, files INTEGER, errors INTEGER, skipped_robots INTEGER);
            CREATE TABLE IF NOT EXISTS errors (
              id INTEGER PRIMARY KEY AUTOINCREMENT, url TEXT, message TEXT,
              recorded_at TEXT DEFAULT CURRENT_TIMESTAMP);
            ''')
            columns = {row[1] for row in con.execute('PRAGMA table_info(documents)')}
            for column, declaration in (
                ('category', "TEXT DEFAULT 'other'"),
                ('version_tag', 'TEXT'),
                ('logical_url', 'TEXT'),
                ('source_count', 'INTEGER DEFAULT 1'),
            ):
                if column not in columns:
                    con.execute(f'ALTER TABLE documents ADD COLUMN {column} {declaration}')
            con.executescript('''
            CREATE TABLE IF NOT EXISTS version_events (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              logical_url TEXT NOT NULL, document_url TEXT NOT NULL,
              previous_url TEXT, event_type TEXT NOT NULL,
              detected_at TEXT DEFAULT CURRENT_TIMESTAMP);
            CREATE INDEX IF NOT EXISTS idx_version_events_logical ON version_events(logical_url);
            ''')
            con.execute('CREATE INDEX IF NOT EXISTS idx_documents_logical ON documents(logical_url)')
            con.execute('CREATE INDEX IF NOT EXISTS idx_documents_category ON documents(category)')
            # Backfill metadata for catalogs created by v1.2 without deleting records.
            for url, extension, source in con.execute(
                    'SELECT url,extension,discovered_from FROM documents WHERE logical_url IS NULL').fetchall():
                con.execute('UPDATE documents SET category=?,version_tag=?,logical_url=? WHERE url=?',
                    (file_category(extension or ''), parse_qs(urlparse(url).query).get('v',[None])[0],
                     logical_file_url(url), url))
                con.execute('INSERT OR IGNORE INTO document_sources(document_url,page_url) VALUES (?,?)',
                    (url, source))

    def connect(self):
        return sqlite3.connect(self.db)

    def allowed(self, url):
        p = urlparse(url)
        host = (p.hostname or '').lower()
        return p.scheme in ('http','https') and any(host == h or host.endswith('.' + h) for h in self.allowed_hosts)

    def robots_for(self, url):
        p = urlparse(url)
        origin = f'{p.scheme}://{p.netloc}'
        if origin not in self.robots:
            robot_url = origin + '/robots.txt'
            rp = RobotFileParser()
            try:
                status, _, body = self.raw_fetch(robot_url, max_bytes=1024*1024)
                if status == 200:
                    rp.parse(body.decode('utf-8', errors='replace').splitlines())
                    self.robots[origin] = (rp, rp.site_maps() or [])
                elif status in (401,403,429) or status >= 500:
                    self.robots[origin] = (None, [])  # fail closed
                elif 300 <= status < 400:
                    self.robots[origin] = (None, [])  # do not assume redirected robots permits crawling
                else:
                    rp.parse([])
                    self.robots[origin] = (rp, [])
            except (OSError, ValueError) as exc:
                self.error(robot_url, f'robots.txt unavailable; skipping origin: {exc}')
                self.robots[origin] = (None, [])
        return self.robots[origin]

    def raw_fetch(self, url, max_bytes=MAX_RESPONSE):
        p = urlparse(url)
        origin = f'{p.scheme}://{p.netloc}'
        wait = self.delay - (time.monotonic() - self.last_request.get(origin, -1e12))
        if wait > 0: time.sleep(wait)
        self.last_request[origin] = time.monotonic()
        req = Request(url, headers={'User-Agent': AGENT, 'Accept': 'text/html,application/xml,text/xml,*/*;q=0.1'})
        try:
            with self.opener.open(req, timeout=self.timeout) as response:
                data = response.read(max_bytes + 1)
                if len(data) > max_bytes: raise ValueError('Response exceeds discovery size limit')
                return response.status, response.headers.get('Content-Type', ''), data
        except HTTPError as e:
            if e.code in (301, 302, 303, 307, 308):
                self.redirects[url] = e.headers.get('Location', '')
            return e.code, e.headers.get('Content-Type', ''), b''

    def error(self, url, message):
        self.stats['errors'] += 1
        with self.connect() as con:
            con.execute('INSERT INTO errors(url,message) VALUES (?,?)', (url, str(message)))
        print(f'[WARN] {url}: {message}')

    def fetch(self, url):
        visited = set()
        original = url
        for _ in range(6):  # at most five redirects
            if url in visited or not self.allowed(url):
                self.error(original, 'Redirect loop or redirect outside allowed hosts')
                return None
            visited.add(url)
            rp, _ = self.robots_for(url)
            if rp is None or not rp.can_fetch(AGENT, url):
                self.stats['skipped_robots'] += 1
                return None
            try:
                status, ctype, data = self.raw_fetch(url)
            except (OSError, ValueError) as exc:
                self.error(url, str(exc))
                return None
            if status == 200:
                self.resolved[original] = url
                return ctype, data
            if status in (301, 302, 303, 307, 308):
                location = self.redirects.get(url)
                if not location:
                    self.error(url, 'Redirect without Location header')
                    return None
                target = canonical(urljoin(url, location))
                if not self.allowed(target):
                    self.error(url, f'Redirect target not allowed: {target}')
                    return None
                print(f'[REDIRECT] {url} -> {target}')
                url = target
                continue
            self.error(url, f'HTTP {status}')
            return None
        self.error(original, 'Too many redirects (maximum 5)')
        return None

    def record_file(self, url, source):
        filename = unquote(urlparse(url).path.rsplit('/',1)[-1]) or 'download'
        ext = Path(filename).suffix.lower()
        category = file_category(ext)
        query = parse_qs(urlparse(url).query)
        version = query.get('v', [None])[0]
        logical = logical_file_url(url)
        with self.connect() as con:
            exists = con.execute('SELECT 1 FROM documents WHERE url=?', (url,)).fetchone()
            if not exists and self.stats['files'] >= self.max_files:
                return
            prior = con.execute('''SELECT url FROM documents WHERE logical_url=? AND url<>?
                ORDER BY last_seen DESC, rowid DESC LIMIT 1''', (logical, url)).fetchone()
            if exists:
                self.stats['known_files'] += 1
            if not exists and prior:
                self.stats['version_changes'] += 1
                con.execute('''INSERT INTO version_events(logical_url,document_url,previous_url,event_type)
                    VALUES (?,?,?,'new_url_version')''', (logical,url,prior[0]))
            con.execute('''INSERT INTO documents
                (url,filename,extension,discovered_from,category,version_tag,logical_url)
                VALUES (?,?,?,?,?,?,?) ON CONFLICT(url) DO UPDATE SET
                last_seen=CURRENT_TIMESTAMP, category=excluded.category,
                version_tag=excluded.version_tag, logical_url=excluded.logical_url''',
                (url, filename, ext, source, category, version, logical))
            con.execute('''INSERT INTO document_sources(document_url,page_url)
                VALUES (?,?) ON CONFLICT(document_url,page_url) DO UPDATE SET
                last_seen=CURRENT_TIMESTAMP''', (url, source))
            con.execute('''UPDATE documents SET source_count=
                (SELECT COUNT(*) FROM document_sources WHERE document_url=?) WHERE url=?''',
                (url, url))
        if not exists:
            self.stats['files'] += 1
            self.stats['new_files'] += 1
            print(f'[FILE] {url}')

    def sitemap_urls(self):
        if not self.use_sitemaps: return []
        _, maps = self.robots_for(self.seed)
        # Only sitemaps explicitly listed in robots.txt; cap work.
        queue = [canonical(m) for m in maps if self.allowed(m)][:10]
        result, seen, discovered = [], set(), set()
        while queue and len(seen) < 20 and len(result) < 1000:
            url = queue.pop(0)
            if url in seen: continue
            seen.add(url)
            response = self.fetch(url)
            if not response: continue
            _, data = response
            try:
                root = ElementTree.fromstring(data)
                root_type = root.tag.rsplit('}', 1)[-1]
                locs = [e.text.strip() for e in root.iter()
                        if e.tag.rsplit('}', 1)[-1] == 'loc' and e.text]
                if root_type == 'sitemapindex':
                    queue.extend(canonical(x) for x in locs if self.allowed(x) and x not in seen)
                elif root_type == 'urlset':
                    for x in locs:
                        x = canonical(x)
                        if self.allowed(x) and x not in discovered:
                            discovered.add(x)
                            result.append(x)
                else:
                    self.error(url, 'Unexpected sitemap root element')
            except ElementTree.ParseError as exc:
                self.error(url, f'Invalid sitemap: {exc}')
        return result[:1000]

    def run(self):
        with self.connect() as con:
            run_id = con.execute('INSERT INTO crawl_runs DEFAULT VALUES').lastrowid
        queue = [self.seed]
        queue.extend(self.sitemap_urls())
        seen = set()
        while queue and self.stats['pages'] < self.max_pages and self.stats['files'] < self.max_files:
            url = queue.pop(0)
            if url in seen or not self.allowed(url): continue
            seen.add(url)
            if is_file(url):
                self.record_file(url, self.seed)
                continue
            response = self.fetch(url)
            if response is None: continue
            final_url = self.resolved.get(url, url)
            if final_url in self.seen_final:
                continue
            self.seen_final.add(final_url)
            ctype, data = response
            if not ('html' in ctype.lower() or data[:100].lstrip().lower().startswith((b'<!doctype html', b'<html'))):
                continue
            parser = LinkParser()
            parser.feed(data.decode('utf-8', errors='replace'))
            self.stats['pages'] += 1
            with self.connect() as con:
                con.execute('INSERT INTO pages(url,title) VALUES (?,?) ON CONFLICT(url) DO UPDATE SET title=excluded.title, scanned_at=CURRENT_TIMESTAMP', (final_url, parser.title.strip()))
            print(f'[PAGE] {final_url}')
            base_url = resolve_link(final_url, parser.base_href) if parser.base_href else final_url
            for href, download_attr in parser.links:
                link = resolve_link(base_url, href)
                if not self.allowed(link): continue
                if is_file(link) or download_attr:
                    self.record_file(link, final_url)
                    if self.stats['files'] >= self.max_files: break
                elif link not in seen and link not in queue and link not in self.seen_final and len(queue) < 3000:
                    queue.append(link)
        with self.connect() as con:
            con.execute('UPDATE crawl_runs SET finished_at=CURRENT_TIMESTAMP, pages=?,files=?,errors=?,skipped_robots=? WHERE id=?',
                        (*[self.stats[k] for k in ('pages','files','errors','skipped_robots')], run_id))
        return self.stats

def canonical(url):
    url, _ = urldefrag(url)
    p = urlparse(url)
    return urlunparse((p.scheme.lower(), p.netloc.lower(), p.path or '/', p.params, p.query, ''))

def resolve_link(page_url, href):
    """Resolve BSI CMS root-relative paths that omit their leading slash."""
    href = href.strip()
    if (urlparse(page_url).hostname == 'www.bsi.bund.de'
            and href.startswith(('DE/', 'EN/', 'SharedDocs/', 'SiteGlobals/'))):
        href = '/' + href
    return canonical(urljoin(page_url, href))

def is_file(url):
    return Path(unquote(urlparse(url).path)).suffix.lower() in EXTENSIONS

def file_category(extension):
    if extension in {'.pdf','.doc','.docx','.odt','.rtf','.txt','.epub'}: return 'document'
    if extension in {'.xls','.xlsx','.ods','.csv'}: return 'table'
    if extension in {'.ppt','.pptx','.odp'}: return 'presentation'
    if extension in {'.zip','.7z','.tar','.gz'}: return 'archive'
    if extension in {'.jpg','.jpeg','.png','.svg','.gif','.webp'}: return 'image'
    if extension in {'.mp3','.mp4'}: return 'media'
    if extension in {'.asc','.sig','.p7s','.pem','.cer','.crt','.der'}: return 'signature_or_certificate'
    return 'other'

def logical_file_url(url):
    """Group URLs that differ only by the BSI CMS publication version parameter."""
    from urllib.parse import parse_qsl, urlencode
    p = urlparse(url)
    query = urlencode([(k,v) for k,v in parse_qsl(p.query, keep_blank_values=True) if k != 'v'])
    return urlunparse((p.scheme, p.netloc, p.path, p.params, query, ''))

def export_csv(db: Path, output: Path):
    output.parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(db) as con, output.open('w', encoding='utf-8', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['url','filename','extension','category','version_tag','logical_url',
                         'source_count','discovered_from','first_seen','last_seen','status'])
        writer.writerows(con.execute('''SELECT url,filename,extension,category,version_tag,
                         logical_url,source_count,discovered_from,first_seen,last_seen,status
                         FROM documents ORDER BY url'''))
