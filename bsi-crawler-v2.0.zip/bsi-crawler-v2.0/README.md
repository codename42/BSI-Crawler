# BSI-Dokumentenkatalog – Version 1.3

Linux-Kommandozeilenprogramm (Python 3.10+, nur Standardbibliothek). Es **katalogisiert** öffentliche Dateilinks, lädt aber **keine Dateiinhalte** herunter. Eine grafische Oberfläche ist noch nicht enthalten.

## Installation und Prüfung

Im entpackten Ordner `bsi-crawler-phase1`:

```bash
python3 -m unittest discover -s tests -v
```

Es sollten **6 Tests** erfolgreich sein. Der Test verwendet einen lokalen HTTP-Server und benötigt keinen BSI-Netzzugriff.

## Kleiner Testlauf

```bash
python3 main.py crawl --seed https://www.bsi.bund.de/ --max-pages 100 --max-files 200 --delay 3 --no-sitemaps --db data/catalog_v13.sqlite3
python3 main.py list --db data/catalog_v13.sqlite3 --category document --limit 20
python3 main.py list --db data/catalog_v13.sqlite3 --extension pdf --limit 20
python3 main.py export --db data/catalog_v13.sqlite3 --output data/bsi_documents_v13.csv
```

Für die zusätzliche Sitemap-Suche `--no-sitemaps` weglassen. Nur die in `robots.txt` angegebenen Sitemaps werden berücksichtigt (höchstens 20 Sitemap-Dateien, 1000 Sitemap-URLs). Die Datei `data/catalog_v13.sqlite3` wird bei Bedarf erstellt. Bestehende v1.2-Datenbanken werden beim Öffnen um die neuen Spalten ergänzt; vor der Migration empfiehlt sich eine Sicherungskopie.

## Neu in Version 1.3

- Dokumentkategorien: `document`, `table`, `presentation`, `archive`, `image`, `media`, `signature_or_certificate`, `other`.
- Speicherung der BSI-CMS-Versionskennung aus `?v=...` in `version_tag` und einer `logical_url` ohne den Versionsparameter. **Die Versionskennung ist keine nachgewiesene Dokumentversion.**
- Mehrere Fundseiten pro Datei in `document_sources`, mit `source_count` in `documents`.
- CSV-Export mit Kategorie, Version, logischer URL und Fundseitenanzahl.
- Bessere Erkennung von XML-Sitemaps mit und ohne XML-Namespace.
- Vermeidung mehrfacher HTML-Auswertung nach Weiterleitungen während eines Crawl-Laufs.
- HTML-`<base href>`-Unterstützung und die BSI-spezifische Korrektur für root-relative Pfade ohne führenden Schrägstrich.
- Automatische Schema-Erweiterung älterer SQLite-Kataloge, einschließlich Metadaten-Nachpflege.

## Grenzen

- Die Dateierkennung basiert auf URL-Endungen und HTML-`download`-Attributen. Sie bestätigt weder Existenz noch MIME-Typ oder Dateiinhalte.
- Keine Datei-Downloads, Inhaltsprüfsummen, echte Versionshistorie, Excel-XLSX-Ausgabe, Desktop-Oberfläche oder Zeitplanung.
- Die `files`-Statistik zählt neu entdeckte Datei-URLs im aktuellen Lauf, nicht alle Datenbankeinträge.
- Die `pages`-Statistik zählt verarbeitete HTML-Seiten; bei Sitemap-URLs und Dateilinks können andere Grenzen greifen.
- Die Sitemap-Suche ist begrenzt, kein Anspruch auf vollständige Erfassung aller BSI-Dokumente.
- `robots.txt` wird pro Host geprüft; der Crawler beschränkt sich auf erlaubte Hosts und wartet standardmäßig zwischen Anfragen.
- Der Crawler führt kein JavaScript aus und folgt keinen Links auf fremde Hosts.

## Projektdateien

- `main.py`: CLI für `crawl`, `list`, `export`
- `bsi_crawler/core.py`: Crawling, SQLite, Sitemap-Verarbeitung, CSV
- `tests/test_core.py`: lokale Tests


## Version 1.4 – Download-Manager

Nach einem Crawl mit `--db data/catalog.sqlite3` stehen folgende Befehle bereit:

```bash
python3 main.py list --db data/catalog.sqlite3 --category document --limit 20
python3 main.py download --db data/catalog.sqlite3 --id 5 --dry-run
python3 main.py download --db data/catalog.sqlite3 --id 5
python3 main.py download --db data/catalog.sqlite3 --id 5 --id 8
python3 main.py download --db data/catalog.sqlite3 --category document --limit 10
python3 main.py download --db data/catalog.sqlite3 --all --limit 20 --dry-run
python3 main.py download --db data/catalog.sqlite3 --all --limit 20
```

`--all` lädt **maximal `--limit`** Dateien pro Aufruf (Standard: 20), einschließlich Bildern. Für Dokumente ohne Bilder `--category document` verwenden. `--output-dir` wählt den Speicherort (Standard: `downloads/`). `--max-mb` begrenzt die Größe je Datei (Standard: 100 MiB); `--delay` setzt die Wartezeit zwischen HTTP-Anfragen (Standard: 3 Sekunden). `--force` lädt auch bereits erfolgreich gespeicherte Dateien erneut herunter. Der Katalog wird nicht gelöscht.

Die IDs stammen aus `python3 main.py list` und entsprechen SQLite-`rowid`-Werten. Erfolgreiche Downloads, SHA-256, Größe und Pfad werden in `downloads` gespeichert; `download_attempts` protokolliert Versuche. Bereits erfolgreich heruntergeladene Dateien werden nach Prüfsummenprüfung übersprungen. Fehlgeschlagene Versuche können erneut ausgeführt werden. Während des Downloads wird eine `.part`-Datei verwendet und nach erfolgreichem Abschluss atomar umbenannt. **Ein abgebrochener Teiltransfer wird nicht fortgesetzt**, sondern beim nächsten Versuch neu gestartet. Der Downloader akzeptiert ausschließlich Weiterleitungen zum selben Host, prüft `robots.txt` und setzt ein Größenlimit.

Hinweis: Dies ist ein CLI-Prototyp; noch keine grafische Oberfläche und keine historische Dateiversionierung. Zuerst `--dry-run` und kleine Mengen testen.

## Version 1.5 – Versionsverwaltung

Die bestehende Datenbank `data/catalog_v14.sqlite3` kann unverändert weiterverwendet
werden. Vor dem ersten Einsatz eine Sicherungskopie anlegen:

```bash
cp data/catalog_v14.sqlite3 data/catalog_v14.backup.sqlite3
python3 main.py history --db data/catalog_v14.sqlite3 --limit 20
python3 main.py crawl --seed https://www.bsi.bund.de/ --max-pages 100 --max-files 200 --delay 3 --db data/catalog_v14.sqlite3
python3 main.py history --db data/catalog_v14.sqlite3 --limit 20
```

Neue URLs mit geändertem `v=`-Parameter werden als `new_url_version` in
`version_events` protokolliert, sofern eine andere URL derselben logischen
Datei bereits im Katalog vorhanden ist. Ein unveränderter URL-Eintrag
löst kein neues Ereignis aus. Frühere URLs bleiben im Katalog.

`download_versions` speichert SHA-256-Prüfsummen für erfolgreich heruntergeladene
Dateiinhalte. Beim erneuten Herunterladen mit `--force` wird ein geänderter
Inhalt vor dem Überschreiben unter `downloads/history/<ID>/` archiviert.
Für unterschiedliche URL-Versionen entstehen ohnehin separate Downloads.

**Einschränkungen:** Eine geänderte Datei unter derselben URL wird erst beim
expliziten erneuten Download mit `--force` erkannt; ein Crawl allein prüft
keine Datei-Inhalte. Ein Versionswechsel anhand des URL-Parameters ist kein
Beweis für geänderten Datei-Inhalt. Historische Downloads aus v1.4 werden
nicht automatisch in die neue Historientabelle importiert; beim ersten
erneuten Download werden bestehende Dateien jedoch gesichert, falls sich
der Inhalt unterscheidet. Der Befehl `history` zeigt die neuen
Ereignisse und Inhaltsversionen an.

## Version 1.5.1: Zeitstempel und Crawl-Statistik

Bestehende Datenbanken (auch `data/catalog_v14.sqlite3`) bleiben verwendbar. Vor dem ersten Aufruf empfiehlt sich eine Sicherung.

```bash
cp data/catalog_v14.sqlite3 data/catalog_v14.backup.sqlite3
python3 main.py downloads-history --db data/catalog_v14.sqlite3 --limit 30
python3 main.py download --db data/catalog_v14.sqlite3 --category document --limit 5
python3 main.py downloads-history --db data/catalog_v14.sqlite3 --limit 30
```

Die Download-Tabelle speichert `first_downloaded_at` (erster erfolgreicher Download), `downloaded_at` (letzter erfolgreicher Download) und `last_checked_at` (letzte lokale SHA-256-Prüfung oder letzter HTTP-Downloadversuch). Ein `[SKIP]` prüft **nur die lokale Datei**; er bestätigt keine unveränderte Remote-Datei. `--force` fordert die Datei erneut vom Server an. Bestehende `downloaded_at`-Werte werden bei der Migration als erster Downloadzeitpunkt übernommen; unbekannte Zeitpunkte bleiben leer. SQLite `CURRENT_TIMESTAMP` ist UTC. Die CLI zeigt UTC an.

Der Crawl meldet zusätzlich `new_files`, `known_files` (erneute Linkfunde, nicht eindeutige Dateien) und `version_changes`. Die bisherige Kennzahl `files` bleibt aus Kompatibilitätsgründen erhalten und zählt neu erfaßte URLs.
