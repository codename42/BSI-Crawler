"""Crash-resilient, database-backed traversal of previously unvisited pages."""
import sqlite3
from urllib.parse import urlparse
from .core import Crawler, LinkParser, canonical, resolve_link, is_file

class ResumeCrawler(Crawler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        with self.connect() as con:
            con.execute('''CREATE TABLE IF NOT EXISTS crawl_frontier (
                url TEXT PRIMARY KEY, state TEXT NOT NULL DEFAULT 'pending',
                attempts INTEGER NOT NULL DEFAULT 0, last_error TEXT,
                discovered_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP)''')
            con.execute("UPDATE crawl_frontier SET state='pending' WHERE state='processing'")
            con.execute("INSERT OR IGNORE INTO crawl_frontier(url) VALUES (?)", (self.seed,))
            # Existing page rows are already scanned; don't re-fetch them.
            con.execute("UPDATE crawl_frontier SET state='done' WHERE url IN (SELECT url FROM pages)")

    def enqueue(self, url):
        url = canonical(url)
        if not self.allowed(url) or is_file(url):
            return
        with self.connect() as con:
            con.execute('''INSERT OR IGNORE INTO crawl_frontier(url,state)
                SELECT ?, 'pending' WHERE NOT EXISTS (SELECT 1 FROM pages WHERE url=?)''', (url,url))

    def status(self):
        with self.connect() as con:
            return dict(con.execute('SELECT state, COUNT(*) FROM crawl_frontier GROUP BY state'))

    def run_resume(self, max_attempts=3):
        # Sitemap discovery is repeated on startup; entries are deduplicated.
        if self.use_sitemaps:
            for url in self.sitemap_urls():
                self.enqueue(url)
        processed = 0
        while processed < self.max_pages:
            with self.connect() as con:
                row = con.execute('''SELECT url FROM crawl_frontier WHERE state='pending'
                    ORDER BY discovered_at,url LIMIT 1''').fetchone()
                if row is None: break
                url = row[0]
                con.execute("UPDATE crawl_frontier SET state='processing', attempts=attempts+1, updated_at=CURRENT_TIMESTAMP WHERE url=?", (url,))
            processed += 1
            if not self.allowed(url):
                state = 'blocked'
            elif self._already_scanned(url):
                state = 'done'
            else:
                before_errors = self.stats['errors']
                before_robots = self.stats['skipped_robots']
                response = self.fetch(url)
                if response is None:
                    state = 'blocked' if self.stats['skipped_robots'] > before_robots else 'failed'
                else:
                    final_url = self.resolved.get(url, url)
                    ctype, data = response
                    if not ('html' in ctype.lower() or data[:100].lstrip().lower().startswith((b'<!doctype html',b'<html'))):
                        state = 'done'
                    else:
                        parser = LinkParser()
                        parser.feed(data.decode('utf-8', errors='replace'))
                        base = resolve_link(final_url, parser.base_href) if parser.base_href else final_url
                        # Commit page, discovered links and file records before marking done.
                        with self.connect() as con:
                            con.execute('''INSERT INTO pages(url,title) VALUES (?,?)
                                ON CONFLICT(url) DO UPDATE SET title=excluded.title,scanned_at=CURRENT_TIMESTAMP''', (final_url,parser.title.strip()))
                        self.stats['pages'] += 1
                        print('[PAGE]',final_url)
                        for href,download_attr in parser.links:
                            link = resolve_link(base,href)
                            if not self.allowed(link): continue
                            if is_file(link) or download_attr:
                                self.record_file(link,final_url)
                            else:
                                self.enqueue(link)
                        if final_url != url:
                            self.enqueue(final_url)
                        state = 'done'
            with self.connect() as con:
                if state == 'failed':
                    attempts = con.execute('SELECT attempts FROM crawl_frontier WHERE url=?',(url,)).fetchone()[0]
                    if attempts < max_attempts:
                        state = 'pending'
                    else:
                        state = 'failed'
                con.execute('UPDATE crawl_frontier SET state=?,updated_at=CURRENT_TIMESTAMP WHERE url=?',(state,url))
        states = self.status()
        print('Resume summary:', self.stats, 'frontier:', states)
        if states.get('pending',0) == 0 and states.get('processing',0) == 0:
            if states.get('failed',0) or states.get('blocked',0):
                print('Keine offenen Seiten; einige Seiten konnten nicht verarbeitet werden.')
            else:
                print('Keine weiteren neuen Seiten gefunden (innerhalb der entdeckten Links).')
        else:
            print('Fortsetzung möglich: weitere unbearbeitete Seiten vorhanden.')
        return states

    def _already_scanned(self,url):
        with self.connect() as con:
            return con.execute('SELECT 1 FROM pages WHERE url=?',(url,)).fetchone() is not None
