#!/usr/bin/env python3
"""CLI for the bounded BSI document discovery prototype."""
import argparse
from pathlib import Path
import sqlite3
from urllib.parse import urlparse
from bsi_crawler.core import Crawler, export_csv
from bsi_crawler.resume import ResumeCrawler
from bsi_crawler.downloads import DownloadManager

def main():
    p = argparse.ArgumentParser(description='BSI document catalog and download manager v1.5.2')
    sub = p.add_subparsers(dest='command', required=True)
    crawl = sub.add_parser('crawl', help='Discover linked files')
    crawl.add_argument('--seed', default='https://www.bsi.bund.de/')
    crawl.add_argument('--allowed-host', action='append', default=[], help='Allowed hostname; repeatable')
    crawl.add_argument('--max-pages', type=int, default=15)
    crawl.add_argument('--max-files', type=int, default=100)
    crawl.add_argument('--delay', type=float, default=2.0)
    crawl.add_argument('--timeout', type=float, default=15.0)
    crawl.add_argument('--no-sitemaps', action='store_true')
    crawl.add_argument('--db', type=Path, default=Path('data/catalog.sqlite3'))
    resume = sub.add_parser('resume', help='Continue discovering only unvisited pages')
    resume.add_argument('--seed', default='https://www.bsi.bund.de/')
    resume.add_argument('--allowed-host', action='append', default=[])
    resume.add_argument('--max-pages', type=int, default=100)
    resume.add_argument('--delay', type=float, default=2.0)
    resume.add_argument('--timeout', type=float, default=15.0)
    resume.add_argument('--no-sitemaps', action='store_true')
    resume.add_argument('--db', type=Path, default=Path('data/catalog.sqlite3'))
    status = sub.add_parser('crawl-status', help='Show persistent crawl queue status')
    status.add_argument('--db', type=Path, default=Path('data/catalog.sqlite3'))
    export = sub.add_parser('export', help='Export catalog to CSV')
    export.add_argument('--db', type=Path, default=Path('data/catalog.sqlite3'))
    export.add_argument('--output', type=Path, default=Path('data/bsi_documents.csv'))
    ls = sub.add_parser('list', help='Print discovered documents')
    ls.add_argument('--db', type=Path, default=Path('data/catalog.sqlite3'))
    ls.add_argument('--limit', type=int, default=30)
    ls.add_argument('--category', choices=['document','table','presentation','archive','image','media','signature_or_certificate','other'])
    ls.add_argument('--extension', help='e.g. pdf or .pdf')
    dl = sub.add_parser('download', help='Download selected catalogued files')
    dl.add_argument('--db', type=Path, default=Path('data/catalog.sqlite3'))
    dl.add_argument('--output-dir', type=Path, default=Path('downloads'))
    dl.add_argument('--id', type=int, action='append', dest='ids', help='Catalog ID; repeatable')
    dl.add_argument('--category', choices=['document','table','presentation','archive','image','media','signature_or_certificate','other'])
    dl.add_argument('--all', action='store_true', dest='all_files')
    dl.add_argument('--limit', type=int, default=20, help='Maximum files in category/all selection (default: 20)')
    dl.add_argument('--delay', type=float, default=3.0)
    dl.add_argument('--timeout', type=float, default=30.0)
    dl.add_argument('--max-mb', type=int, default=100)
    dl.add_argument('--force', action='store_true')
    dl.add_argument('--dry-run', action='store_true')
    history = sub.add_parser('history', help='Show URL version changes and downloaded file versions')
    history.add_argument('--db', type=Path, default=Path('data/catalog.sqlite3'))
    history.add_argument('--limit', type=int, default=30)
    timestamps = sub.add_parser('downloads-history', help='Show download timestamps and verification history')
    timestamps.add_argument('--db', type=Path, default=Path('data/catalog.sqlite3'))
    timestamps.add_argument('--limit', type=int, default=30)
    args = p.parse_args()
    if args.command == 'crawl':
        if args.max_pages < 1 or args.max_files < 1 or args.delay < 0 or args.timeout <= 0:
            p.error('max-pages, max-files and timeout must be positive; delay must be nonnegative')
        host = urlparse(args.seed).hostname
        if not host or urlparse(args.seed).scheme not in ('http','https'):
            p.error('seed must be an http(s) URL')
        hosts = args.allowed_host or [host]
        if not any(host == h or host.endswith('.'+h) for h in hosts):
            p.error('seed hostname must be within allowed hosts')
        crawler = Crawler(args.db, args.seed, hosts, args.max_pages, args.max_files, args.delay, args.timeout, not args.no_sitemaps)
        print('Summary:', crawler.run())
    elif args.command == 'resume':
        if args.max_pages < 1 or args.delay < 0 or args.timeout <= 0: p.error('Invalid limits')
        host = urlparse(args.seed).hostname
        hosts = args.allowed_host or [host]
        if not host or urlparse(args.seed).scheme not in ('http','https') or not any(host == h or host.endswith('.'+h) for h in hosts):
            p.error('Invalid seed or allowed hosts')
        crawler = ResumeCrawler(args.db,args.seed,hosts,args.max_pages,10**9,args.delay,args.timeout,not args.no_sitemaps)
        crawler.run_resume()
    elif args.command == 'crawl-status':
        if not args.db.exists(): p.error('Database not found')
        with sqlite3.connect(args.db) as con:
            try: rows = con.execute('SELECT state,COUNT(*) FROM crawl_frontier GROUP BY state').fetchall()
            except sqlite3.OperationalError: p.error('No resume queue yet; run resume first')
        print('Crawl frontier:', dict(rows))
    elif args.command == 'export':
        if not args.db.exists(): p.error('Database not found; run crawl first')
        export_csv(args.db, args.output)
        print('CSV exported:', args.output)
    elif args.command == 'history':
        if not args.db.exists(): p.error('Database not found; run crawl first')
        with sqlite3.connect(args.db) as con:
            # Initialize the new schema for databases created with older versions.
            con.executescript('''CREATE TABLE IF NOT EXISTS version_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT, logical_url TEXT NOT NULL,
                document_url TEXT NOT NULL, previous_url TEXT,
                event_type TEXT NOT NULL, detected_at TEXT DEFAULT CURRENT_TIMESTAMP);
                CREATE TABLE IF NOT EXISTS download_versions (
                id INTEGER PRIMARY KEY AUTOINCREMENT, document_url TEXT NOT NULL,
                local_path TEXT NOT NULL, sha256 TEXT NOT NULL, bytes INTEGER NOT NULL,
                downloaded_at TEXT DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(document_url,sha256));''')
            print('URL-Versionswechsel:')
            for row in con.execute('SELECT detected_at,event_type,previous_url,document_url FROM version_events ORDER BY id DESC LIMIT ?', (max(0,args.limit),)):
                print('\t'.join(str(x or '-') for x in row))
            print('Gespeicherte Datei-Versionen:')
            for row in con.execute('SELECT downloaded_at,document_url,sha256,local_path FROM download_versions ORDER BY id DESC LIMIT ?', (max(0,args.limit),)):
                print('\t'.join(str(x or '-') for x in row))
    elif args.command == 'downloads-history':
        if not args.db.exists(): p.error('Database not found; run crawl first')
        # Run the additive migration for existing databases.
        DownloadManager(args.db, Path('downloads'), 0, 30, 100 * 1024 * 1024)
        with sqlite3.connect(args.db) as con:
            print('ID\tDatei\tErster Download (UTC)\tLetzter Download (UTC)\tLetzte lokale/HTTP-Prüfung (UTC)\tStatus')
            for row in con.execute('''SELECT d.rowid,d.filename,x.first_downloaded_at,x.downloaded_at,
                x.last_checked_at,x.status FROM downloads x JOIN documents d ON d.url=x.document_url
                ORDER BY x.downloaded_at DESC LIMIT ?''', (max(0,args.limit),)):
                print('\t'.join(str(v if v is not None else '-') for v in row))
    elif args.command == 'download':
        if not args.db.exists(): p.error('Database not found; run crawl first')
        if args.limit < 1 or args.delay < 0 or args.timeout <= 0 or args.max_mb < 1:
            p.error('Invalid download limits')
        manager = DownloadManager(args.db, args.output_dir, args.delay, args.timeout, args.max_mb * 1024 * 1024)
        try: rows = manager.select(args.ids, args.category, args.all_files, args.limit)
        except ValueError as exc: p.error(str(exc))
        print('Download summary:', manager.download(rows, force=args.force, dry_run=args.dry_run))
    else:
        if not args.db.exists(): p.error('Database not found; run crawl first')
        with sqlite3.connect(args.db) as con:
            sql = 'SELECT rowid,url,filename,category,version_tag FROM documents WHERE 1=1'
            params = []
            if args.category:
                sql += ' AND category=?'; params.append(args.category)
            if args.extension:
                sql += ' AND extension=?'; params.append('.' + args.extension.lower().lstrip('.'))
            sql += ' ORDER BY url LIMIT ?'; params.append(max(0,args.limit))
            for doc_id, url, name, category, version in con.execute(sql, params):
                print(f'{doc_id}\t{name}\t{category}\tv={version or "-"}\t{url}')
if __name__ == '__main__': main()
